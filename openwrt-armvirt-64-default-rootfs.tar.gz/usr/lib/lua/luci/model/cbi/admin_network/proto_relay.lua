local e,t,e=...
local d,e
local h,a,o,i,r,n
d=t:taboption("general",Value,"ipaddr",
translate("Local IPv4 address"),
translate("Address to access local relay bridge"))
d.datatype="ip4addr"
e=s:taboption("general",DynamicList,"network",translate("Relay between networks"))
e.widget="checkbox"
e.exclude=arg[1]
e.template="cbi/network_netlist"
e.nocreate=true
e.nobridges=true
e.novirtual=true
e:depends("proto","relay")
h=t:taboption("advanced",Flag,"forward_bcast",
translate("Forward broadcast traffic"))
h.default=h.enabled
a=t:taboption("advanced",Flag,"forward_dhcp",
translate("Forward DHCP traffic"))
a.default=a.enabled
o=t:taboption("advanced",Value,"gateway",
translate("Use DHCP gateway"),
translate("Override the gateway in DHCP responses"))
o.datatype="ip4addr"
o:depends("forward_dhcp",a.enabled)
i=t:taboption("advanced",Value,"expiry",
translate("Host expiry timeout"),
translate("Specifies the maximum amount of seconds after which hosts are presumed to be dead"))
i.placeholder="30"
i.datatype="min(1)"
r=t:taboption("advanced",Value,"retry",
translate("ARP retry threshold"),
translate("Specifies the maximum amount of failed ARP requests until hosts are presumed to be dead"))
r.placeholder="5"
r.datatype="min(1)"
n=t:taboption("advanced",Value,"table",
translate("Use routing table"),
translate("Override the table used for internal routes"))
n.placeholder="16800"
n.datatype="range(0,65535)"
